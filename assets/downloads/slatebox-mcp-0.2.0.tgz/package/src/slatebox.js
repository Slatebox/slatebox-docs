#!/usr/bin/env node
import { readFileSync } from "node:fs";
import { parseArgs } from "node:util";
import { SlateboxApiError, SlateboxClient } from "./client.js";

const help = `Usage:
  slatebox read SHARE_ID [--full]
  slatebox preview SHARE_ID PLAN_FILE
  slatebox apply SHARE_ID PLAN_FILE --idempotency-key KEY

Use - for PLAN_FILE to read JSON from standard input. Supply a plan with
message and operations, or an object containing plan and userMessage.
Preview does not save. Apply saves the edit. Reuse the same key to retry
the same edit; choose a fresh key for a different edit or slate.

Set SLATEBOX_API_TOKEN to a personal access token. Set SLATEBOX_BASE_URL
or pass --base-url ORIGIN for a self-hosted instance (default https://api.slatebox.com).
Results are JSON on stdout. Errors are written to stderr.
`;

class UsageError extends Error {}

function argumentsFor(argv) {
  let parsed;
  try {
    parsed = parseArgs({ args: argv, allowPositionals: true, options: {
      help: { type: "boolean", short: "h" },
      full: { type: "boolean" },
      "idempotency-key": { type: "string" },
      "base-url": { type: "string" },
    } });
  } catch {
    throw new UsageError("Unknown option or missing option value.");
  }
  const { values, positionals } = parsed;
  if (values.help || (positionals.length === 1 && positionals[0] === "help")) return null;
  const [command, shareId, file] = positionals;
  if (!["read", "preview", "apply"].includes(command)) throw new UsageError("Choose read, preview or apply.");
  if (!shareId || !/^[a-zA-Z0-9_-]+$/.test(shareId)) throw new UsageError("Supply the share ID from the slate URL.");
  if (positionals.length !== (command === "read" ? 2 : 3)) throw new UsageError("Incorrect number of arguments.");
  if (values.full && command !== "read") throw new UsageError("--full is available for read.");
  const key = values["idempotency-key"];
  if (command === "apply" && (!key || !/^[!-~]+$/.test(key))) {
    throw new UsageError("Apply requires --idempotency-key KEY using printable characters without spaces.");
  }
  if (command !== "apply" && key !== undefined) throw new UsageError("Supply an idempotency key only when applying an edit.");
  return { command, shareId, file, full: values.full, key, baseUrl: values["base-url"] };
}

function apiOrigin(input) {
  let url;
  try { url = new URL(input); } catch { throw new UsageError("Invalid Slatebox API origin."); }
  if (!["http:", "https:"].includes(url.protocol) || url.pathname !== "/" || url.username || url.password || url.search || url.hash) {
    throw new UsageError("Supply an HTTP or HTTPS origin without credentials, path, query or fragment.");
  }
  return url.origin;
}

function readPlan(file) {
  let source, input;
  try { source = readFileSync(file === "-" ? 0 : file, "utf8"); }
  catch { throw new UsageError("Could not read the plan file."); }
  try { input = JSON.parse(source); }
  catch { throw new UsageError("The plan must be valid JSON."); }
  const envelope = input && typeof input === "object" && Object.hasOwn(input, "plan");
  const plan = envelope ? input.plan : input;
  const userMessage = envelope ? input.userMessage ?? "" : "";
  if (!plan || typeof plan.message !== "string" || !plan.message.trim() ||
      !Array.isArray(plan.operations) || !plan.operations.length) {
    throw new UsageError("A plan must contain a message and a nonempty operations array.");
  }
  if (typeof userMessage !== "string") throw new UsageError("userMessage must be a string.");
  if (envelope && Object.keys(input).some(key => !["plan", "userMessage"].includes(key))) {
    throw new UsageError("The request envelope accepts only plan and userMessage. Use the command to choose preview or apply.");
  }
  if (!envelope && Object.keys(plan).some(key => !["message", "operations"].includes(key))) {
    throw new UsageError("A plan accepts only message and operations. Put userMessage alongside plan in an envelope.");
  }
  return { plan, userMessage };
}

async function main() {
  const args = argumentsFor(process.argv.slice(2));
  if (!args) { process.stdout.write(help); return; }
  const token = process.env.SLATEBOX_API_TOKEN;
  const baseUrl = apiOrigin(args.baseUrl ?? process.env.SLATEBOX_BASE_URL ?? "https://api.slatebox.com");
  const client = new SlateboxClient({ baseUrl, token });
  let result;
  if (args.command === "read") {
    result = await client.getSlate(args.shareId, { includeFull: args.full });
  } else {
    const { plan, userMessage } = readPlan(args.file);
    result = await client.applyOperations(args.shareId, plan, {
      userMessage, dryRun: args.command === "preview", idempotencyKey: args.key,
    });
  }
  // An untrusted endpoint could echo a request header in its JSON.
  const json = JSON.stringify(result, (_key, value) =>
    typeof value === "string" ? value.replaceAll(token, "[redacted]") : value, 2);
  process.stdout.write(json + "\n");
}

main().catch(error => {
  const token = process.env.SLATEBOX_API_TOKEN;
  const message = token ? error.message.replaceAll(token, "[redacted]") : error.message;
  const status = error instanceof SlateboxApiError ? `HTTP ${error.status}: ` : "";
  process.stderr.write(`slatebox: ${status}${message}\n`);
  if (error instanceof UsageError) process.stderr.write("Run slatebox --help for usage.\n");
  process.exitCode = error instanceof UsageError ? 2 : 1;
});

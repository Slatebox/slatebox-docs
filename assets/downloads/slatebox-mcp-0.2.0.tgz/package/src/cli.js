#!/usr/bin/env node
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { SlateboxClient } from "./client.js";
import { createSlateboxMcpServer } from "./server.js";

function argument(name) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : null;
}

const baseUrl =
  argument("--base-url") ||
  process.env.SLATEBOX_BASE_URL ||
  "https://app.slatebox.com";
const token = process.env.SLATEBOX_API_TOKEN;

try {
  const client = new SlateboxClient({ baseUrl, token });
  const server = createSlateboxMcpServer(client);
  await server.connect(new StdioServerTransport());
} catch (error) {
  process.stderr.write(`Slatebox MCP could not start: ${error.message}\n`);
  process.exitCode = 1;
}

export class SlateboxApiError extends Error {
  constructor(message, { status, code, details } = {}) {
    super(message);
    this.name = "SlateboxApiError";
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export class SlateboxClient {
  constructor({
    baseUrl = "https://app.slatebox.com",
    token,
    fetchImpl = fetch,
  }) {
    if (!token) throw new Error("SLATEBOX_API_TOKEN is required.");
    this.baseUrl = baseUrl.replace(/\/$/, "");
    this.token = token;
    this.fetch = fetchImpl;
  }

  async request(path, options = {}) {
    const response = await this.fetch(`${this.baseUrl}${path}`, {
      ...options,
      headers: {
        authorization: `Bearer ${this.token}`,
        "content-type": "application/json",
        ...options.headers,
      },
    });
    const payload = await response.json().catch(() => {
      if (response.ok) throw new SlateboxApiError("The endpoint did not return JSON. Check the Slatebox API origin.", { status: response.status });
      return {};
    });
    if (!response.ok) {
      throw new SlateboxApiError(
        payload.error?.message || `Slatebox returned HTTP ${response.status}.`,
        {
          status: response.status,
          code: payload.error?.code,
          details: payload,
        },
      );
    }
    return payload;
  }

  getSlate(shareId, { includeFull = false } = {}) {
    const query = includeFull ? "?include=full" : "";
    return this.request(
      `/api/v1/slates/${encodeURIComponent(shareId)}${query}`,
    );
  }

  applyOperations(
    shareId,
    plan,
    { userMessage = "", dryRun = false, idempotencyKey } = {},
  ) {
    return this.request(
      `/api/v1/slates/${encodeURIComponent(shareId)}/operations`,
      {
        method: "POST",
        headers: idempotencyKey ? { "idempotency-key": idempotencyKey } : {},
        body: JSON.stringify({ plan, userMessage, dryRun }),
      },
    );
  }
}

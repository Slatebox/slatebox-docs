#!/usr/bin/env node
import { createSlateInput } from "./operations.js";
import { readFileSync } from "node:fs";
import { parseArgs } from "node:util";
import { SlateboxApiError, SlateboxClient } from "./client.js";

const help = `Usage:
  slatebox create "TEAM QUESTION" --idempotency-key KEY
  slatebox read SHARE_ID [--full]
  slatebox move SHARE_ID CARD LANE [--apply --revision N --idempotency-key KEY]
  slatebox preview SHARE_ID PLAN_FILE
  slatebox apply SHARE_ID PLAN_FILE --idempotency-key KEY

Create saves a private decision map from a one-line brief (up to 160 characters).
Retry with the same brief and key to get the original map.

Move accepts card and lane IDs or unique labels. It previews by default. To save,
use the revision returned by your preview. Use IDs for reliable retries after a rename.

Use - for PLAN_FILE to read JSON from standard input. Supply a plan with
message and operations, or an object containing plan and userMessage.
Preview does not save. Apply saves the edit. Reuse the same key to retry
the same edit; choose a fresh key for a different edit or slate.

Set SLATEBOX_API_TOKEN to a personal access token. Set SLATEBOX_BASE_URL
or pass --base-url ORIGIN for a self-hosted instance (default https://api.slatebox.com).
Results are JSON on stdout. Errors are written to stderr.
`;

class UsageError extends Error {}

function argumentsFor(argv) {
  let parsed;
  try {
    parsed = parseArgs({ args: argv, allowPositionals: true, options: {
      help: { type: "boolean", short: "h" },
      full: { type: "boolean" },
      apply: { type: "boolean" },
      revision: { type: "string" },
      "idempotency-key": { type: "string" },
      "base-url": { type: "string" },
    } });
  } catch {
    throw new UsageError("Unknown option or missing option value.");
  }
  const { values, positionals } = parsed;
  if (values.help || (positionals.length === 1 && positionals[0] === "help")) return null;
  const [command, shareId, target, lane] = positionals;
  if (command === "create") {
    if (positionals.length !== 2 || values.full || values.apply || values.revision !== undefined) {
      throw new UsageError('Use slatebox create "TEAM QUESTION" --idempotency-key KEY.');
    }
    const input = createSlateInput.safeParse({ brief: shareId, idempotency_key: values["idempotency-key"] });
    if (!input.success) throw new UsageError("Create requires a plain one-line brief (1–160 characters, no angle brackets) and --idempotency-key KEY.");
    return { command, brief: input.data.brief, key: input.data.idempotency_key, baseUrl: values["base-url"] };
  }
  if (!["read", "preview", "apply", "move"].includes(command)) throw new UsageError("Choose create, read, move, preview or apply.");
  if (!shareId || !/^[a-zA-Z0-9_-]+$/.test(shareId)) throw new UsageError("Supply the share ID from the slate URL.");
  if (positionals.length !== {read: 2, move: 4, preview: 3, apply: 3}[command]) throw new UsageError("Incorrect number of arguments.");
  if (values.full && command !== "read") throw new UsageError("--full is available for read.");
  const key = values["idempotency-key"];
  const savingMove = command === "move" && values.apply;
  if (values.apply && command !== "move") throw new UsageError("--apply is available for move.");
  if (savingMove && (!/^(0|[1-9][0-9]*)$/.test(values.revision ?? "") || !Number.isSafeInteger(Number(values.revision)))) {
    throw new UsageError("Saving a move requires --revision N from the preview.");
  }
  if (!savingMove && values.revision !== undefined) throw new UsageError("Use --revision with move --apply.");
  const saving = command === "apply" || savingMove;
  if (saving && (!key || !/^[!-~]+$/.test(key))) {
    throw new UsageError("Apply requires --idempotency-key KEY using printable characters without spaces.");
  }
  if (!saving && key !== undefined) throw new UsageError("Supply an idempotency key only when applying an edit.");
  return { command, shareId, target, lane, savingMove, revision: Number(values.revision), full: values.full, key, baseUrl: values["base-url"] };
}

function apiOrigin(input) {
  let url;
  try { url = new URL(input); } catch { throw new UsageError("Invalid Slatebox API origin."); }
  if (!["http:", "https:"].includes(url.protocol) || url.pathname !== "/" || url.username || url.password || url.search || url.hash) {
    throw new UsageError("Supply an HTTP or HTTPS origin without credentials, path, query or fragment.");
  }
  return url.origin;
}

function readPlan(file) {
  let source, input;
  try { source = readFileSync(file === "-" ? 0 : file, "utf8"); }
  catch { throw new UsageError("Could not read the plan file."); }
  try { input = JSON.parse(source); }
  catch { throw new UsageError("The plan must be valid JSON."); }
  const envelope = input && typeof input === "object" && Object.hasOwn(input, "plan");
  const plan = envelope ? input.plan : input;
  const userMessage = envelope ? input.userMessage ?? "" : "";
  if (!plan || typeof plan.message !== "string" || !plan.message.trim() ||
      !Array.isArray(plan.operations) || !plan.operations.length) {
    throw new UsageError("A plan must contain a message and a nonempty operations array.");
  }
  if (typeof userMessage !== "string") throw new UsageError("userMessage must be a string.");
  if (envelope && Object.keys(input).some(key => !["plan", "userMessage"].includes(key))) {
    throw new UsageError("The request envelope accepts only plan and userMessage. Use the command to choose preview or apply.");
  }
  if (!envelope && Object.keys(plan).some(key => !["message", "operations"].includes(key))) {
    throw new UsageError("A plan accepts only message and operations. Put userMessage alongside plan in an envelope.");
  }
  return { plan, userMessage };
}

function workshopId(items, value, kind) {
  const byId = items.find(item => item.id === value);
  if (byId) return byId.id;
  const matches = items.filter(item => item.label === value);
  if (matches.length === 1) return matches[0].id;
  throw new UsageError(matches.length
    ? 'Multiple ' + kind + ' labels match. Use the ' + kind + ' ID from slatebox read.'
    : 'Unknown ' + kind + '. Use an ID or exact label from slatebox read.');
}

async function moveCard(client, args) {
  const {summary} = await client.getSlate(args.shareId);
  const workshop = summary?.workshop;
  if (!Array.isArray(workshop?.cards) || !Array.isArray(workshop?.lanes) || !Number.isSafeInteger(workshop.revision)) {
    throw new UsageError("Choose an interactive workshop or a map to move a card.");
  }
  const operation = {
    kind: "move_workshop_card",
    cardId: workshopId(workshop.cards, args.target, "card"),
    laneId: workshopId(workshop.lanes, args.lane, "lane"),
    expectedRevision: args.savingMove ? args.revision : workshop.revision,
  };
  return client.applyOperations(args.shareId, {message: "Move the workshop card", operations: [operation]}, {
    dryRun: !args.savingMove, idempotencyKey: args.key,
  });
}

async function main() {
  const args = argumentsFor(process.argv.slice(2));
  if (!args) { process.stdout.write(help); return; }
  const token = process.env.SLATEBOX_API_TOKEN;
  const baseUrl = apiOrigin(args.baseUrl ?? process.env.SLATEBOX_BASE_URL ?? "https://api.slatebox.com");
  const client = new SlateboxClient({ baseUrl, token });
  let result;
  if (args.command === "create") {
    result = await client.createSlate(args.brief, args.key);
  } else if (args.command === "read") {
    result = await client.getSlate(args.shareId, { includeFull: args.full });
  } else if (args.command === "move") {
    result = await moveCard(client, args);
  } else {
    const { plan, userMessage } = readPlan(args.target);
    result = await client.applyOperations(args.shareId, plan, {
      userMessage, dryRun: args.command === "preview", idempotencyKey: args.key,
    });
  }
  // An untrusted endpoint could echo a request header in its JSON.
  const json = JSON.stringify(result, (_key, value) =>
    typeof value === "string" ? value.replaceAll(token, "[redacted]") : value, 2);
  process.stdout.write(json + "\n");
}

main().catch(error => {
  const token = process.env.SLATEBOX_API_TOKEN;
  const message = token ? error.message.replaceAll(token, "[redacted]") : error.message;
  const status = error instanceof SlateboxApiError ? `HTTP ${error.status}: ` : "";
  process.stderr.write(`slatebox: ${status}${message}\n`);
  if (error instanceof UsageError) process.stderr.write("Run slatebox --help for usage.\n");
  process.exitCode = error instanceof UsageError ? 2 : 1;
});

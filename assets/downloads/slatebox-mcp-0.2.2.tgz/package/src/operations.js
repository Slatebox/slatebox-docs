import { z } from "zod";

export const createSlateInput = z.strictObject({
  brief: z.string().trim().min(1).max(160).regex(/^[^<>\u0000-\u001f\u007f]+$/u),
  idempotency_key: z.string().min(1).max(128).regex(/^[!-~]+$/),
});

export function operationPlan(message, operations) {
  return { message, operations };
}

export function addNodesOperation({
  count,
  shape,
  text,
  referenceNodeId,
  direction = "right",
  arrangement,
  gap,
  width,
  height,
  style,
}) {
  return {
    kind: "add_nodes",
    count,
    shape,
    ...(text ? { text } : {}),
    ...(width ? { width } : {}),
    ...(height ? { height } : {}),
    ...(style ? { style } : {}),
    placement: {
      ...(referenceNodeId ? { relativeTo: referenceNodeId } : {}),
      direction,
      ...(arrangement ? { arrangement } : {}),
      ...(gap !== undefined ? { gap } : {}),
    },
  };
}

export function targetSelector({ nodeIds, matchingText }) {
  return {
    ...(nodeIds?.length ? { ids: nodeIds } : {}),
    ...(matchingText ? { text: matchingText } : {}),
  };
}

export function toolResult(value) {
  return {
    content: [{ type: "text", text: JSON.stringify(value, null, 2) }],
    structuredContent: value,
  };
}

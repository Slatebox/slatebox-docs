import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import {
  addNodesOperation,
  editMap,
  mapBranchInput,
  mapOutcomeInput,
  createSlateInput,
  issueInviteInput,
  revokeInviteInput,
  operationPlan,
  targetSelector,
  toolResult,
} from "./operations.js";

const shape = z.enum([
  "rectangle",
  "roundedrectangle",
  "ellipse",
  "circle",
  "star",
  "triangle",
  "pentagon",
  "hexagon",
  "octagon",
  "trapezium",
  "parallelogram",
  "rarrow",
  "larrow",
  "diamond",
]);
const direction = z.enum(["left", "right", "above", "below", "center"]);
const arrangement = z.enum(["row", "column", "grid"]);
const nodeStyle = z
  .object({
    backgroundColor: z.string().optional(),
    foregroundColor: z.string().optional(),
    borderColor: z.string().optional(),
    borderWidth: z.number().min(0).optional(),
    borderOpacity: z.number().min(0).max(1).optional(),
    borderStyle: z.string().optional(),
    opacity: z.number().min(0).max(1).optional(),
    fontFamily: z.string().optional(),
    fontSize: z.number().positive().optional(),
  })
  .strict();
const nodeChanges = nodeStyle
  .extend({
    text: z.string().optional(),
    shape: shape.optional(),
    x: z.number().optional(),
    y: z.number().optional(),
    width: z.number().min(20).max(5000).optional(),
    height: z.number().min(20).max(5000).optional(),
    rotationAngle: z.number().optional(),
    textXAlign: z.enum(["left", "middle", "right"]).optional(),
    textYAlign: z.enum(["top", "middle", "bottom"]).optional(),
    animation: z.string().optional(),
    locked: z.boolean().optional(),
  })
  .strict();
const connectionStyle = z
  .object({
    label: z.string().optional(),
    lineColor: z.string().optional(),
    lineWidth: z.number().positive().optional(),
    lineOpacity: z.number().min(0).max(1).optional(),
    lineType: z.string().optional(),
    lineCurveType: z.enum(["cubic", "quadratic"]).optional(),
    lineCurviness: z.number().min(0).max(1).optional(),
    showParentArrow: z.boolean().optional(),
    showChildArrow: z.boolean().optional(),
  })
  .strict();
const connectionChanges = connectionStyle;
const slateChanges = z
  .object({
    name: z.string().optional(),
    description: z.string().optional(),
    background: z.record(z.string(), z.unknown()).optional(),
  })
  .strict();
const selectorFields = {
  node_ids: z.array(z.string()).optional(),
  matching_text: z.string().optional(),
};

function requestOptions(input) {
  return {
    userMessage: input.user_message || "",
    dryRun: input.dry_run || false,
    idempotencyKey: input.idempotency_key,
  };
}

export function createSlateboxMcpServer(client) {
  const server = new McpServer({ name: "slatebox", version: "0.2.4" });

  server.registerTool(
    "create_slate",
    {
      title: "Create a private decision map",
      description: "Create a new private editable decision map when the user requests one. Supply their brief and a fresh idempotency key. Retry the same brief with the same key to get the original map.",
      inputSchema: createSlateInput,
    },
    async ({ brief, idempotency_key }) =>
      toolResult(await client.createSlate(brief, idempotency_key)),
  );

  server.registerTool(
    "create_slate_invite",
    {
      title: "Create or update an invitation link",
      description: "When the owner asks to share, grant the requested role to anyone holding the link. Changing the role also changes access for existing link holders. Requires slates:share. Return the URL to the owner and keep inviteId for revocation.",
      inputSchema: issueInviteInput,
    },
    async ({ share_id, role, idempotency_key }) =>
      toolResult(await client.issueInvite(share_id, role, idempotency_key)),
  );

  server.registerTool(
    "revoke_slate_invite",
    {
      title: "Revoke an invitation link",
      description: "When the owner asks to stop sharing through this link, revoke the inviteId returned by create_slate_invite. Requires slates:share. A replacement invitation has its own ID.",
      inputSchema: revokeInviteInput,
      annotations: { destructiveHint: true, idempotentHint: true },
    },
    async ({ share_id, invite_id, idempotency_key }) =>
      toolResult(await client.revokeInvite(share_id, invite_id, idempotency_key)),
  );

  server.registerTool(
    "get_slate",
    {
      title: "Get Slate",
      description:
        "Read a slate summary or its full JSON. On a workshop, summary.workshop lists the revision, cards, current lanes and legal destinations.",
      inputSchema: {
        share_id: z.string(),
        include_full: z.boolean().optional(),
      },
    },
    async ({ share_id, include_full }) =>
      toolResult(
        await client.getSlate(share_id, { includeFull: include_full }),
      ),
  );

  server.registerTool(
    "add_map_branch",
    {
      title: "Add a branch and arrival outcome",
      description: "Preview a new path from a station ID or exact unique label. To save, use the preview revision as expected_revision, set dry_run false and supply a fresh idempotency_key.",
      inputSchema: mapBranchInput,
    },
    async input => toolResult(await editMap(client, input)),
  );
  server.registerTool(
    "update_map_outcome",
    {
      title: "Edit the outcome at a station",
      description: "Preview replacement arrival text for a station ID or exact unique label. To save, use the preview revision as expected_revision, set dry_run false and supply a fresh idempotency_key.",
      inputSchema: mapOutcomeInput,
    },
    async input => toolResult(await editMap(client, input)),
  );

  server.registerTool(
    "move_workshop_card",
    {
      title: "Move a workshop card",
      description: "Preview a card or token moving to a legal lane. Read get_slate first for the IDs and current revision. Set dry_run to false and provide an idempotency key to save the move.",
      inputSchema: {
        share_id: z.string(),
        card_id: z.string(),
        lane_id: z.string(),
        expected_revision: z.number().int().nonnegative(),
        dry_run: z.boolean().default(true),
        idempotency_key: z.string().trim().min(1).optional(),
      },
    },
    async ({ share_id, card_id, lane_id, expected_revision, dry_run, idempotency_key }) => {
      if (!dry_run && !idempotency_key) {
        throw new Error("Provide an idempotency_key when saving a move.");
      }
      const plan = operationPlan("Move the workshop card", [{
        kind: "move_workshop_card",
        cardId: card_id,
        laneId: lane_id,
        expectedRevision: expected_revision,
      }]);
      return toolResult(await client.applyOperations(share_id, plan, {
        dryRun: dry_run,
        idempotencyKey: idempotency_key,
      }));
    },
  );

  server.registerTool(
    "apply_slate_operations",
    {
      title: "Apply Slate Operations",
      description:
        "Apply a validated multi-operation plan. Unrequested content and slate styling are preserved.",
      inputSchema: {
        share_id: z.string(),
        message: z.string(),
        operations: z.array(z.record(z.string(), z.unknown())).min(1).max(50),
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) =>
      toolResult(
        await client.applyOperations(
          input.share_id,
          operationPlan(input.message, input.operations),
          requestOptions(input),
        ),
      ),
  );

  server.registerTool(
    "add_nodes",
    {
      title: "Add Nodes",
      description:
        "Add one or more shaped nodes, optionally positioned relative to a node id.",
      inputSchema: {
        share_id: z.string(),
        count: z.number().int().min(1).max(20),
        shape,
        text: z.string().optional(),
        reference_node_id: z.string().optional(),
        direction: direction.optional(),
        arrangement: arrangement.optional(),
        gap: z.number().min(0).max(2000).optional(),
        width: z.number().positive().optional(),
        height: z.number().positive().optional(),
        style: nodeStyle.optional(),
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) => {
      const plan = operationPlan(
        `Done — I added ${input.count} ${input.shape}${input.count === 1 ? "" : " nodes"}.`,
        [
          addNodesOperation({
            count: input.count,
            shape: input.shape,
            text: input.text,
            referenceNodeId: input.reference_node_id,
            direction: input.direction,
            arrangement: input.arrangement,
            gap: input.gap,
            width: input.width,
            height: input.height,
            style: input.style,
          }),
        ],
      );
      return toolResult(
        await client.applyOperations(
          input.share_id,
          plan,
          requestOptions(input),
        ),
      );
    },
  );

  server.registerTool(
    "update_nodes",
    {
      title: "Update Nodes",
      description:
        "Change text, shape, size, position, color, typography, animation, or lock state.",
      inputSchema: {
        share_id: z.string(),
        ...selectorFields,
        changes: nodeChanges,
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) =>
      toolResult(
        await client.applyOperations(
          input.share_id,
          operationPlan("Done — I updated the selected nodes.", [
            {
              kind: "update_nodes",
              target: targetSelector(input),
              changes: input.changes,
            },
          ]),
          requestOptions(input),
        ),
      ),
  );

  server.registerTool(
    "delete_nodes",
    {
      title: "Delete Nodes",
      description:
        "Delete explicitly selected nodes. Deleting all nodes requires explicit user intent.",
      inputSchema: {
        share_id: z.string(),
        ...selectorFields,
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) =>
      toolResult(
        await client.applyOperations(
          input.share_id,
          operationPlan("Done — I removed the selected nodes.", [
            { kind: "delete_nodes", target: targetSelector(input) },
          ]),
          requestOptions(input),
        ),
      ),
  );

  server.registerTool(
    "connect_nodes",
    {
      title: "Connect Nodes",
      description:
        "Add or remove a relationship between explicitly selected nodes.",
      inputSchema: {
        share_id: z.string(),
        from_node_ids: z.array(z.string()).min(1),
        to_node_ids: z.array(z.string()).min(1),
        disconnect: z.boolean().optional(),
        style: connectionStyle.optional(),
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) =>
      toolResult(
        await client.applyOperations(
          input.share_id,
          operationPlan(
            input.disconnect
              ? "Done — I removed the selected connection."
              : "Done — I connected the selected nodes.",
            [
              {
                kind: input.disconnect ? "disconnect_nodes" : "connect_nodes",
                from: { ids: input.from_node_ids },
                to: { ids: input.to_node_ids },
                ...(input.style ? { style: input.style } : {}),
              },
            ],
          ),
          requestOptions(input),
        ),
      ),
  );

  server.registerTool(
    "disconnect_nodes",
    {
      title: "Disconnect Nodes",
      description:
        "Remove a relationship between explicitly selected source and target nodes.",
      inputSchema: {
        share_id: z.string(),
        from_node_ids: z.array(z.string()).min(1),
        to_node_ids: z.array(z.string()).min(1),
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) =>
      toolResult(
        await client.applyOperations(
          input.share_id,
          operationPlan("Done — I removed the selected connection.", [
            {
              kind: "disconnect_nodes",
              from: { ids: input.from_node_ids },
              to: { ids: input.to_node_ids },
            },
          ]),
          requestOptions(input),
        ),
      ),
  );

  server.registerTool(
    "update_connections",
    {
      title: "Update Connections",
      description:
        "Change existing relationship labels, colors, widths, opacity, path style, curve settings, or independent arrowheads.",
      inputSchema: {
        share_id: z.string(),
        connection_ids: z.array(z.string()).min(1),
        changes: connectionChanges,
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) =>
      toolResult(
        await client.applyOperations(
          input.share_id,
          operationPlan("Done — I updated the selected connections.", [
            {
              kind: "update_connections",
              connectionIds: input.connection_ids,
              changes: input.changes,
            },
          ]),
          requestOptions(input),
        ),
      ),
  );

  server.registerTool(
    "arrange_nodes",
    {
      title: "Arrange Nodes",
      description: "Arrange selected nodes in a row, column, grid, or circle.",
      inputSchema: {
        share_id: z.string(),
        ...selectorFields,
        layout: z.enum(["row", "column", "grid", "circle"]),
        gap: z.number().min(0).max(2000).optional(),
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) =>
      toolResult(
        await client.applyOperations(
          input.share_id,
          operationPlan(
            `Done — I arranged the selected nodes in a ${input.layout}.`,
            [
              {
                kind: "arrange_nodes",
                target: targetSelector(input),
                layout: input.layout,
                ...(input.gap !== undefined ? { gap: input.gap } : {}),
              },
            ],
          ),
          requestOptions(input),
        ),
      ),
  );

  server.registerTool(
    "update_slate",
    {
      title: "Update Slate",
      description:
        "Change a slate name, description, or explicitly requested canvas background.",
      inputSchema: {
        share_id: z.string(),
        changes: slateChanges,
        user_message: z.string(),
        dry_run: z.boolean().optional(),
        idempotency_key: z.string().optional(),
      },
    },
    async (input) =>
      toolResult(
        await client.applyOperations(
          input.share_id,
          operationPlan("Done — I updated the slate.", [
            { kind: "update_slate", changes: input.changes },
          ]),
          requestOptions(input),
        ),
      ),
  );

  return server;
}

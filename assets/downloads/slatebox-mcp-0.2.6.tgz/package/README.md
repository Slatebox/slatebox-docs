# Slatebox CLI and MCP server

The `slatebox` command creates a private diagram or decision map, reads a slate, previews a change and applies it. The `slatebox-mcp` command exposes the same API to an MCP client over standard input and output. Both use the permissions of the account that issued the token.

## Install

Use Node.js 20 or later. Download the archive and checksum from the Slatebox docs. The archive includes the JavaScript source of both commands and the MIT license.

```sh
curl -fLO https://docs.slatebox.com/assets/downloads/slatebox-mcp-0.2.6.tgz
curl -fLO https://docs.slatebox.com/assets/downloads/slatebox-mcp-0.2.6.tgz.sha256
shasum -a 256 -c slatebox-mcp-0.2.6.tgz.sha256
npm install --global ./slatebox-mcp-0.2.6.tgz
slatebox --help
```

On Linux you can also verify the checksum with `sha256sum -c slatebox-mcp-0.2.6.tgz.sha256`. npm installs the public MCP SDK and Zod dependencies.

## Read and edit a slate

Open **Profile → Developer access** in your Slatebox account and create a token. Supply it in the `SLATEBOX_API_TOKEN` environment variable. Set `SLATEBOX_BASE_URL` to your own instance’s origin when self-hosting. For the hosted service, both commands accept `https://api.slatebox.com`.

To draw an editable flow, pass `--kind diagram`. Arrows connect successive steps. Each line can start another path. Set `--source` to `call-status`, `interview-notes` or `sign-in-outage` to include that public drawing. Your token needs `slates:write`.

```sh
slatebox create 'Request -> Review -> Ship' --kind diagram --idempotency-key release-flow-1
```

The result includes the canvas URL and a `diagram` summary with its native notes and connections. In MCP, call `create_slate` with the same `brief`, `kind`, optional `source` and `idempotency_key`. Keep the original arguments and key on retries.

To start a private decision map, supply its opening question and a key for this request. The JSON response includes the canvas URL, share ID and workshop summary.

```sh
slatebox create 'Who approves a refund?' --idempotency-key refund-map-1
```

With an MCP client, call `create_slate` with `{"brief":"Who approves a refund?","idempotency_key":"refund-map-1"}`. Both entry points require a token with `slates:write`. Reuse the same brief and key to retrieve the original result after an interrupted request.

Use the share ID from the slate’s canvas URL. For example, to add one note, save the following as `plan.json`.

```json
{
  "message": "Add the review step.",
  "operations": [
    {
      "kind": "add_nodes",
      "count": 1,
      "shape": "rectangle",
      "text": "Review the import",
      "placement": { "direction": "right" }
    }
  ]
}
```

```sh
slatebox read "$SLATE_ID"
slatebox preview "$SLATE_ID" plan.json
slatebox apply "$SLATE_ID" plan.json --idempotency-key import-review-1
```

Preview leaves the slate untouched. Apply returns the saved result as JSON. Reuse the key when retrying that same change. Choose a fresh key for a different change or slate. Use `read --full` to include the native board data, or use `-` for the plan filename to read JSON from a pipe.

## Add a branch to a decision map

Give the source station’s exact label or ID, a name for the destination and the outcome visitors will see when they reach it. This previews a single change to the map.

```sh
slatebox branch "$SLATE_ID" 'Start' 'Ask Finance' --outcome 'Finance verifies the refund amount.'
```

Read `workshop.revision` in the preview. For a preview at revision 0, save with the following command.

```sh
slatebox branch "$SLATE_ID" 'Start' 'Ask Finance' --outcome 'Finance verifies the refund amount.' --apply --revision 0 --idempotency-key finance-review-1
```

The result includes the new station ID in `report.addedBranches`. To revise its arrival text, preview `slatebox outcome "$SLATE_ID" 'Ask Finance' 'Finance checks the receipt.'`, then use the returned revision and a new key to save. If a teammate edits the board between preview and save, preview again before applying. Use station IDs to retry a request after labels change.

To decide what the audience sees first, preview the full sequence by ID or exact unique label:

```sh
slatebox order "$SLATE_ID" 'Ask Finance' 'Start' 'Next step'
```

Read the preview's `workshop.revision` and `report.presentationOrder`. To save, repeat the command with `--apply --revision N --idempotency-key presentation-1`, replacing N with the reviewed revision. Use the same key and ordered IDs to retry. The MCP tool `set_presentation_order` takes `share_id` and a `scenes` array with the same save options as branch authoring. Map routes and card placements retain their existing layout.

MCP clients can call `add_map_branch` with `share_id`, `from_station`, `label` and `outcome`, or `update_map_outcome` with `share_id`, `station` and `outcome`. To commit the preview, include `dry_run: false`, `expected_revision` and `idempotency_key`. A token needs slate read and write scopes and access to edit the map.

## Share an invitation

In **Profile → Developer access**, select `slates:share` when issuing the owner’s token. Choose the role everyone using the unlisted link should receive.

```sh
slatebox share "$SLATE_ID" --role read --idempotency-key review-link-1
```

Give the returned `url` to the reviewer. Keep the separate `inviteId` for revocation. To change access for everyone holding that same link, run `share` again with `--role comment` or `--role edit` and a new key. To end access through the link, pass its ID.

```sh
slatebox unshare "$SLATE_ID" --invite-id "$INVITE_ID" --idempotency-key end-review-1
```

A later invitation gets a new URL and ID. Retrying an old issue request after revocation returns a conflict. The MCP equivalents are `create_slate_invite` with `share_id`, `role` and `idempotency_key`, and `revoke_slate_invite` with `share_id`, `invite_id` and `idempotency_key`.

## Use an MCP client

Choose a local stdio server in your MCP client, set its command to the installed `slatebox-mcp` executable and pass `SLATEBOX_API_TOKEN` through the client’s secret or environment settings. If the client runs outside your shell, supply the full path printed by `command -v slatebox-mcp`. You can set `SLATEBOX_BASE_URL` or pass `--base-url` followed by your Slatebox origin.

Start with `get_slate`. Tools for adding or updating nodes, connecting them, arranging them and changing the slate accept `dry_run` for previews and `idempotency_key` for retries. The complete tool and input list is available through MCP’s `tools/list`.

To move a card from the terminal, use its ID or quote its exact label and the destination lane label. The first command previews and reports the saved revision. The second commits using that revision (shown here as 3). Use the same IDs, revision and key when retrying.

```sh
slatebox move "$SLATE_ID" 'Second $200' 'Partner newsletter · $200 per placement'
slatebox move "$SLATE_ID" fund-1 newsletter --apply --revision 3 --idempotency-key newsletter-pilot-1
```

On a playable map or workshop, read `summary.workshop` with `get_slate`. Pass a card, a legal lane and the observed revision to `move_workshop_card` to preview the move. To save it, also supply `dry_run: false` and an `idempotency_key`.

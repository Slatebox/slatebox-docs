import { z } from "zod";

const idempotencyKey = z.string().min(1).max(128).regex(/^[!-~]+$/);
const invitationFields = {
  share_id: z.string().min(1).regex(/^[a-zA-Z0-9_-]+$/),
  idempotency_key: idempotencyKey,
};

export const issueInviteInput = z.strictObject({
  ...invitationFields,
  role: z.enum(["read", "comment", "edit"]),
});

export const revokeInviteInput = z.strictObject({
  ...invitationFields,
  invite_id: z.string().regex(/^[a-f0-9]{32}$/),
});

export const createSlateInput = z.strictObject({
  brief: z.string().trim().min(1).max(1200),
  idempotency_key: idempotencyKey,
  kind: z.enum(["map", "diagram"]).optional().describe("Use diagram for native notes and connections. The default is a playable decision map."),
  source: z.enum(["call-status", "interview-notes", "sign-in-outage"]).optional().describe("A public example drawing to include when kind is diagram."),
}).superRefine(({ brief, kind, source }, ctx) => {
  if (kind === "diagram") {
    if (/[<>\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(brief.replaceAll("->", "→"))) {
      ctx.addIssue({ code: "custom", path: ["brief"], message: "Use plain text for diagram notes. Separate connected steps with arrows." });
    }
    return;
  }
  if (source !== undefined) ctx.addIssue({ code: "custom", path: ["source"], message: "A source requires kind diagram." });
  if (brief.length > 160 || /[<>\u0000-\u001f\u007f]/u.test(brief)) {
    ctx.addIssue({ code: "custom", path: ["brief"], message: "A map brief must be one line of plain text, up to 160 characters." });
  }
});

export function operationPlan(message, operations) {
  return { message, operations };
}

export function addNodesOperation({
  count,
  shape,
  text,
  referenceNodeId,
  direction = "right",
  arrangement,
  gap,
  width,
  height,
  style,
}) {
  return {
    kind: "add_nodes",
    count,
    shape,
    ...(text ? { text } : {}),
    ...(width ? { width } : {}),
    ...(height ? { height } : {}),
    ...(style ? { style } : {}),
    placement: {
      ...(referenceNodeId ? { relativeTo: referenceNodeId } : {}),
      direction,
      ...(arrangement ? { arrangement } : {}),
      ...(gap !== undefined ? { gap } : {}),
    },
  };
}

export function targetSelector({ nodeIds, matchingText }) {
  return {
    ...(nodeIds?.length ? { ids: nodeIds } : {}),
    ...(matchingText ? { text: matchingText } : {}),
  };
}

export function toolResult(value) {
  return {
    content: [{ type: "text", text: JSON.stringify(value, null, 2) }],
    structuredContent: value,
  };
}

export class UsageError extends Error {}

export function workshopId(items, value, kind) {
  const byId = items.find(item => item.id === value);
  if (byId) return byId.id;
  const matches = items.filter(item => item.label === value);
  if (matches.length === 1) return matches[0].id;
  throw new UsageError(matches.length
    ? 'Multiple ' + kind + ' labels match. Use the ' + kind + ' ID from slatebox read.'
    : 'Unknown ' + kind + '. Use an ID or exact label from slatebox read.');
}

const mapText = limit => z.string().regex(/^[^<>\u0000-\u001f\u007f]+$/u).trim().min(1).max(limit);
const editFields = {
  share_id: z.string().regex(/^[a-zA-Z0-9_-]+$/),
  expected_revision: z.number().int().safe().nonnegative().optional(),
  dry_run: z.boolean().default(true),
  idempotency_key: idempotencyKey.optional(),
};
const mapFields = {...editFields, outcome: mapText(160)};
export const presentationOrderInput = z.strictObject({...editFields, scenes:z.array(z.string().min(1)).min(1)});
export const mapBranchInput = z.strictObject({...mapFields, from_station: mapText(80), label: mapText(80)});
export const mapOutcomeInput = z.strictObject({...mapFields, station: mapText(80)});

function checkSaveOptions(input) {
  if (!input.dry_run && (input.expected_revision === undefined || !input.idempotency_key)) {
    throw new UsageError("Saving a change requires the revision from the preview and an idempotency key.");
  }
  if (input.dry_run && input.idempotency_key !== undefined) {
    throw new UsageError("Supply an idempotency key only when saving a change.");
  }
}

export async function orderScenes(client, input) {
  checkSaveOptions(input);
  const {summary} = await client.getSlate(input.share_id);
  const workshop = summary?.workshop;
  if (!workshop?.lanes?.length || !Number.isSafeInteger(workshop.revision)) {
    throw new UsageError("Choose a workshop or an interactive map with scenes.");
  }
  const laneIds = input.scenes.map(scene => {
    // A committed request may be retried by ID after its scene has been removed.
    if (!input.dry_run && !workshop.lanes.some(lane => lane.id === scene || lane.label === scene)) return scene;
    return workshopId(workshop.lanes, scene, "scene");
  });
  if (new Set(laneIds).size !== laneIds.length || (input.dry_run && laneIds.length !== workshop.lanes.length)) {
    throw new UsageError("Include each scene exactly once in presentation order.");
  }
  const operation = {kind:"set_presentation_order", laneIds, expectedRevision:input.expected_revision ?? workshop.revision};
  return client.applyOperations(input.share_id, operationPlan("Set presentation order", [operation]), {
    dryRun: input.dry_run, idempotencyKey: input.idempotency_key,
  });
}

export async function editMap(client, input) {
  checkSaveOptions(input);
  const {summary} = await client.getSlate(input.share_id);
  const workshop = summary?.workshop;
  if (!Array.isArray(workshop?.lanes) || !workshop.lanes.length ||
      !workshop.lanes.every(lane => Array.isArray(lane.next)) || !Number.isSafeInteger(workshop.revision)) {
    throw new UsageError("Choose an interactive map with stations.");
  }
  const expectedRevision = input.expected_revision ?? workshop.revision;
  const branch = input.from_station !== undefined;
  const stationId = workshopId(workshop.lanes, branch ? input.from_station : input.station, "station");
  const operation = branch
    ? {kind:"add_map_branch", fromStationId:stationId, label:input.label, outcome:input.outcome, expectedRevision}
    : {kind:"update_map_outcome", stationId, outcome:input.outcome, expectedRevision};
  const message = branch ? "Add a map branch" : "Update a station outcome";
  return client.applyOperations(input.share_id, operationPlan(message, [operation]), {
    dryRun: input.dry_run, idempotencyKey: input.idempotency_key,
  });
}

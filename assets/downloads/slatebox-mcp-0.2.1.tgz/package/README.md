# Slatebox CLI and MCP server

The `slatebox` command reads a slate, previews a change and applies it. The `slatebox-mcp` command exposes the same API to an MCP client over standard input and output. Both use the permissions of the account that issued the token.

## Install

Use Node.js 20 or later. Download the archive and checksum from the Slatebox docs. The archive includes the JavaScript source of both commands and the MIT license.

```sh
curl -fLO https://docs.slatebox.com/assets/downloads/slatebox-mcp-0.2.1.tgz
curl -fLO https://docs.slatebox.com/assets/downloads/slatebox-mcp-0.2.1.tgz.sha256
shasum -a 256 -c slatebox-mcp-0.2.1.tgz.sha256
npm install --global ./slatebox-mcp-0.2.1.tgz
slatebox --help
```

On Linux you can also verify the checksum with `sha256sum -c slatebox-mcp-0.2.1.tgz.sha256`. npm installs the public MCP SDK and Zod dependencies.

## Read and edit a slate

Open **Profile → Developer access** in your Slatebox account and create a token. Supply it in the `SLATEBOX_API_TOKEN` environment variable. Set `SLATEBOX_BASE_URL` to your own instance’s origin when self-hosting. For the hosted service, both commands accept `https://api.slatebox.com`.

Use the share ID from the slate’s canvas URL. For example, to add one note, save the following as `plan.json`.

```json
{
  "message": "Add the review step.",
  "operations": [
    {
      "kind": "add_nodes",
      "count": 1,
      "shape": "rectangle",
      "text": "Review the import",
      "placement": { "direction": "right" }
    }
  ]
}
```

```sh
slatebox read "$SLATE_ID"
slatebox preview "$SLATE_ID" plan.json
slatebox apply "$SLATE_ID" plan.json --idempotency-key import-review-1
```

Preview leaves the slate untouched. Apply returns the saved result as JSON. Reuse the key when retrying that same change. Choose a fresh key for a different change or slate. Use `read --full` to include the native board data, or use `-` for the plan filename to read JSON from a pipe.

## Use an MCP client

Choose a local stdio server in your MCP client, set its command to the installed `slatebox-mcp` executable and pass `SLATEBOX_API_TOKEN` through the client’s secret or environment settings. If the client runs outside your shell, supply the full path printed by `command -v slatebox-mcp`. You can set `SLATEBOX_BASE_URL` or pass `--base-url` followed by your Slatebox origin.

Start with `get_slate`. Tools for adding or updating nodes, connecting them, arranging them and changing the slate accept `dry_run` for previews and `idempotency_key` for retries. The complete tool and input list is available through MCP’s `tools/list`.

To move a card from the terminal, use its ID or quote its exact label and the destination lane label. The first command previews and reports the saved revision. The second commits using that revision (shown here as 3). Use the same IDs, revision and key when retrying.

```sh
slatebox move "$SLATE_ID" 'Second $200' 'Partner newsletter · $200 per placement'
slatebox move "$SLATE_ID" fund-1 newsletter --apply --revision 3 --idempotency-key newsletter-pilot-1
```

On a playable map or workshop, read `summary.workshop` with `get_slate`. Pass a card, a legal lane and the observed revision to `move_workshop_card` to preview the move. To save it, also supply `dry_run: false` and an `idempotency_key`.

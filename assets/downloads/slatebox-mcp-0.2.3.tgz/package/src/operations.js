import { z } from "zod";

const idempotencyKey = z.string().min(1).max(128).regex(/^[!-~]+$/);
const invitationFields = {
  share_id: z.string().min(1).regex(/^[a-zA-Z0-9_-]+$/),
  idempotency_key: idempotencyKey,
};

export const issueInviteInput = z.strictObject({
  ...invitationFields,
  role: z.enum(["read", "comment", "edit"]),
});

export const revokeInviteInput = z.strictObject({
  ...invitationFields,
  invite_id: z.string().regex(/^[a-f0-9]{32}$/),
});

export const createSlateInput = z.strictObject({
  brief: z.string().trim().min(1).max(160).regex(/^[^<>\u0000-\u001f\u007f]+$/u),
  idempotency_key: idempotencyKey,
});

export function operationPlan(message, operations) {
  return { message, operations };
}

export function addNodesOperation({
  count,
  shape,
  text,
  referenceNodeId,
  direction = "right",
  arrangement,
  gap,
  width,
  height,
  style,
}) {
  return {
    kind: "add_nodes",
    count,
    shape,
    ...(text ? { text } : {}),
    ...(width ? { width } : {}),
    ...(height ? { height } : {}),
    ...(style ? { style } : {}),
    placement: {
      ...(referenceNodeId ? { relativeTo: referenceNodeId } : {}),
      direction,
      ...(arrangement ? { arrangement } : {}),
      ...(gap !== undefined ? { gap } : {}),
    },
  };
}

export function targetSelector({ nodeIds, matchingText }) {
  return {
    ...(nodeIds?.length ? { ids: nodeIds } : {}),
    ...(matchingText ? { text: matchingText } : {}),
  };
}

export function toolResult(value) {
  return {
    content: [{ type: "text", text: JSON.stringify(value, null, 2) }],
    structuredContent: value,
  };
}
